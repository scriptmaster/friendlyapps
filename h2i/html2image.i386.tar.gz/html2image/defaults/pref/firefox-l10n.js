//@line 36 "/builds/work/192src/browser/locales/en-US/firefox-l10n.js"

//@line 38 "/builds/work/192src/browser/locales/en-US/firefox-l10n.js"

pref("general.useragent.locale", "en-US");
