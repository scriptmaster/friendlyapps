//@line 2 "/builds/work/192src/browser/app/profile/channel-prefs.js"
pref("app.update.channel", "default");
